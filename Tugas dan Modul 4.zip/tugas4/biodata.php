<!DOCTYPE html>
<html>
<head>
        <title>HOMEPAGE PRIBADI</title>
</head>
<body>
	<h1><p align="center">HOMEPAGE PRIBADI</title>
    <pre>
	<b>1. NAMA                     :</b> Rifqy Anugerah </br>
	<b>2. NIM                      :</b> 6706213095 <br/>
	<b>3. KELAS                    :</b> D3 RPLA 45-05<br/>
	<b>4. TEMPAT TANGGAL LAHIR     :</b> Jakarta, 29 September 2002
	<b>5. ALAMAT                   :</b> Jl.Harapan Raya No.15, RT01/Rw01, Kelapa Gading Barat, Kelapa Gading, Jakarta Utara, DKI Jakarta
	<b>6. RIWAYAT PENDIDIKAN       :</b><br/>
	<b>      A. SD   :</b> SDN 008 Samarinda Seberang<br/>
	<b>      B. SMP  :</b> SMPN 123 Jakarta Utara<br/>
	<b>      C. SMA  :</b> SMA PGRI 12 Jakarta Utara<br/>
	<b>7. EMAIL                    :</b><a href="999rifqy666@gmail.com">999rifqy666gmail.com</a><br/>
	<b>8. HOMEPAGE                 :</b><a href="www.rifqy.com">www.rifqy.com</a><br/>
	<b>9. HOBBY                    :</b> Berolahraga dan Beladiri<br/>
	</pre>
	<hr></hr>
	<p align="center"><b>10. DESKRIPSI PRIBADI SAYA: </b><br/>
	Saya adalah seorang mahasiswa dari Universitas Telkom, Fakultas Ilmu Terapan, Jurusan D3 Rekayasa Perangkat Lunak Aplikasi, Angkatan 45
	Kelas 05. motto saya "saya diciptakan untuk menjadi seorang pemenang, bukan seorang pecundang".
</body>
</html>	